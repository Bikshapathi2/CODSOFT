import Component from "../signup-flow"

export default function Page() {
  return <Component />
}
